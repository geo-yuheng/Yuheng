# OSMChina-Keqing_sword

基于Python的对`.osm`文件的访问库

## 技术细节和文件

### kqs_class.py

OSM数据对象库

### kqs_crud.py

模拟数据库操作行为，不过只有查是可以批量的，增删只能单id，改是增删组合 ~~省事~~

## 命名来源

项目Leader @Jyunhou 钦点

[![](https://avatars.githubusercontent.com/u/45530478?v=4)](https://zh.wikipedia.org/wiki/%E5%8E%9F%E7%A5%9E%E8%A7%92%E8%89%B2%E5%88%97%E8%A1%A8#%E7%92%83%E6%9C%88%E4%B8%83%E6%98%9F)
